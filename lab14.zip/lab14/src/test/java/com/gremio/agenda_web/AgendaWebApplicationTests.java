package com.gremio.agenda_web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgendaWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
