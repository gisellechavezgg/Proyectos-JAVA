package com.gremio.hola_mundo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HolaMundoApplicationTests {

	@Test
	void contextLoads() {
	}

}
